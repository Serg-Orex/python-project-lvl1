from brain_games.games.engine import get_game_engine
import brain_games.games.even as game


def main():
    get_game_engine(game)


if __name__ == '__main__':
    main()
