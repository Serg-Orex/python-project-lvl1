import brain_games.games.game_prime as game
from brain_games.main import game_engine


def main():
    game_engine(game)


if __name__ == '__main__':
    main()
